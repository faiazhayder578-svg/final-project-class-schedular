# Component Hierarchy Diagram

```
┌─────────────────────────────────────────────────────────────────┐
│                           App.jsx                               │
│                    (Main State Manager)                          │
│  - classes[]                                                     │
│  - favorites[]                                                   │
│  - enrolledClasses[]                                            │
│  - isDarkMode                                                    │
│  - isStudentMode                                                │
│  - notifications[]                                              │
└─────────────────────────────────────────────────────────────────┘
                              │
                              │
        ┌─────────────────────┼─────────────────────┐
        │                     │                     │
        ▼                     ▼                     ▼
┌──────────────┐    ┌──────────────────┐    ┌──────────────┐
│  Sidebar.jsx │    │   Main Content   │    │   Modals     │
│              │    │                  │    │              │
│ - Dashboard  │    │  ┌─────────────┐ │    │ ┌──────────┐ │
│ - Schedule   │    │  │ Header.jsx  │ │    │ │AddClass  │ │
│ - Student    │    │  │             │ │    │ │Modal.jsx │ │
│   View       │    │  │ - Title     │ │    │ │          │ │
│ - Dark Mode  │    │  │ - Notifs    │ │    │ └──────────┘ │
│              │    │  │ - Export    │ │    │              │
│              │    │  │ - AI Btn    │ │    │ ┌──────────┐ │
└──────────────┘    │  │ - Add Btn   │ │    │ │AISchedule│ │
                    │  └─────────────┘ │    │ │Modal.jsx │ │
                    │         │         │    │ │          │ │
                    │         ▼         │    │ └──────────┘ │
                    │  ┌─────────────┐ │    └──────────────┘
                    │  │Dashboard.jsx│ │
                    │  │    OR       │ │
                    │  │ScheduleView │ │
                    │  │   .jsx      │ │
                    │  └─────────────┘ │
                    └──────────────────┘
```

## Component Communication Flow

```
┌─────────────────────────────────────────────────────────────┐
│                    USER INTERACTION                          │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│               Component Event Handler                        │
│  (e.g., onClick, onChange, onSubmit)                        │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│            Callback Function (from App.jsx)                  │
│  - handleAddClass()                                          │
│  - handleEnrollment()                                        │
│  - toggleFavorite()                                          │
│  - etc.                                                      │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│              Update State in App.jsx                         │
│  setClasses(), setFavorites(), etc.                          │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│            React Re-renders Components                       │
│  (Only affected components re-render)                        │
└─────────────────────────────────────────────────────────────┘
                            │
                            ▼
┌─────────────────────────────────────────────────────────────┐
│          localStorage Auto-Updated (useEffect)               │
└─────────────────────────────────────────────────────────────┘
```

## Two Methods for Adding Classes

```
METHOD 1: MANUAL ENTRY                 METHOD 2: AI GENERATION
──────────────────────                 ───────────────────────

User clicks "Add Class"                User clicks "AI Schedule"
         │                                      │
         ▼                                      ▼
AddClassModal opens                    AIScheduleModal opens
         │                                      │
         ▼                                      ▼
Fill form manually                     Add multiple instructors
- Course Code                          - Names
- Section                              - Courses
- Faculty                              - Days (toggle)
- Days                                 - Times (toggle)
- Time                                 - Room preference
- Room                                          │
- Capacity                                      ▼
         │                             Click "Generate Schedules"
         ▼                                      │
Click "Create Entry"                            ▼
         │                             AI analyzes constraints
         ▼                                      │
handleAddClass()                                ▼
         │                             3 optimized options shown
         ▼                                      │
Check for conflicts                             ▼
         │                             User selects one option
         ▼                                      │
Add to classes array                            ▼
         │                             applyGeneratedSchedule()
         ▼                                      │
Single class added ✅                           ▼
                                       Multiple classes added ✅
```

## Feature Distribution

```
┌──────────────────────────────────────────────────────────────┐
│                   ADMINISTRATOR FEATURES                      │
├──────────────────────────────────────────────────────────────┤
│ • View Dashboard (analytics)                                  │
│ • Add Class (manual)                                         │
│ • AI Schedule Generator                                      │
│ • Edit Classes                                               │
│ • Delete Classes                                             │
│ • Export to CSV                                              │
│ • Dark Mode Toggle                                           │
│ • Switch to Student View                                     │
└──────────────────────────────────────────────────────────────┘

┌──────────────────────────────────────────────────────────────┐
│                     STUDENT FEATURES                          │
├──────────────────────────────────────────────────────────────┤
│ • View Class Schedule                                         │
│ • Search Classes                                             │
│ • Enroll in Classes                                          │
│ • Drop Classes                                               │
│ • Favorite Classes (⭐)                                       │
│ • View Enrollment Status                                     │
│ • Conflict Detection                                         │
│ • Dark Mode Toggle                                           │
│ • Return to Admin View                                       │
└──────────────────────────────────────────────────────────────┘
```

## State Management Pattern

```
┌─────────────────────────────────────────────────────────────┐
│                      App.jsx State                           │
├─────────────────────────────────────────────────────────────┤
│                                                              │
│  const [classes, setClasses] = useState([])                 │
│     └─→ Core data: all scheduled classes                    │
│                                                              │
│  const [favorites, setFavorites] = useState([])             │
│     └─→ Student feature: array of class IDs                 │
│                                                              │
│  const [enrolledClasses, setEnrolledClasses] = useState([]) │
│     └─→ Student feature: enrolled class IDs                 │
│                                                              │
│  const [isDarkMode, setIsDarkMode] = useState(false)        │
│     └─→ UI preference: dark/light theme                     │
│                                                              │
│  const [isStudentMode, setIsStudentMode] = useState(false)  │
│     └─→ View mode: admin or student perspective             │
│                                                              │
│  const [notifications, setNotifications] = useState([])     │
│     └─→ System messages: success/error/info                 │
│                                                              │
│  const [activeView, setActiveView] = useState('schedule')   │
│     └─→ Current page: 'dashboard' or 'schedule'             │
│                                                              │
└─────────────────────────────────────────────────────────────┘
```

## File Sizes (Approximate)

```
Component              Lines   Purpose
─────────────────────  ─────   ───────────────────────────
App.jsx                 ~300   Main state & coordination
Sidebar.jsx             ~100   Navigation sidebar
Header.jsx              ~150   Top bar with actions
Dashboard.jsx           ~200   Analytics display
ScheduleView.jsx        ~250   Table & filtering
AddClassModal.jsx       ~200   Manual class form
AIScheduleModal.jsx     ~450   AI generation wizard
─────────────────────────────────────────────────────────
TOTAL                  ~1650   lines of React code
```

## Technology Stack

```
┌─────────────────────────────────────┐
│         Frontend Framework          │
│            React 19.2.0             │
└─────────────────────────────────────┘
              │
    ┌─────────┼─────────┐
    ▼         ▼         ▼
┌────────┐ ┌────────┐ ┌────────────┐
│ Vite   │ │Tailwind│ │Lucide Icons│
│(Build) │ │  CSS   │ │  (Icons)   │
└────────┘ └────────┘ └────────────┘
              │
              ▼
    ┌─────────────────────┐
    │   Claude AI API     │
    │ (Schedule Generator)│
    └─────────────────────┘
```

This visual guide helps understand the complete structure! 🎨
