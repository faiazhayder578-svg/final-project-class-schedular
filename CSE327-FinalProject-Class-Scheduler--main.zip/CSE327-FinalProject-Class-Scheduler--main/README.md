For backend:
cd backend

python -m venv 327TP

327TP\Scripts\activate

pip install -r requirements.txt

python app.py




For Frontend:
npm install
npm run dev






Usernames/passwords:
Monalisa / Mona@123

Abrar / Abrar@456

Faiaz / Faiaz@789

Rezwan / Rezwan@000

